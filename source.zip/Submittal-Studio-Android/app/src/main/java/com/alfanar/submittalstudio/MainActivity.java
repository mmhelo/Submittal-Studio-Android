package com.alfanar.submittalstudio;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.util.Base64;
import android.widget.Toast;

import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 9001;
    private final Map<String, OutputStream> streams = new HashMap<>();
    private final Map<String, Uri> uris = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);

        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                String[] accept = params != null ? params.getAcceptTypes() : null;
                if (accept != null && accept.length > 0) {
                    java.util.ArrayList<String> clean = new java.util.ArrayList<>();
                    for (String t : accept) if (t != null && !t.trim().isEmpty()) clean.add(t);
                    if (!clean.isEmpty()) intent.putExtra(Intent.EXTRA_MIME_TYPES, clean.toArray(new String[0]));
                }
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try { startActivityForResult(Intent.createChooser(intent, "Select Submittal Files"), FILE_CHOOSER_REQUEST); }
                catch (Exception e) { filePathCallback = null; return false; }
                return true;
            }
        });

        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html");
        else webView.restoreState(savedInstanceState);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST || filePathCallback == null) return;
        Uri[] results = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                results = new Uri[count];
                for (int i=0;i<count;i++) results[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) results = new Uri[]{data.getData()};
        }
        filePathCallback.onReceiveValue(results);
        filePathCallback = null;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    private String safeName(String input) {
        String n = input == null ? "download.bin" : input.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        return n.isEmpty() ? "download.bin" : n;
    }

    public class AndroidBridge {
        @JavascriptInterface
        public String beginDownload(String filename, String mime) {
            try {
                String token = UUID.randomUUID().toString();
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, safeName(filename));
                values.put(MediaStore.Downloads.MIME_TYPE, (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime);
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Submittal Studio");
                values.put(MediaStore.Downloads.IS_PENDING, 1);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) return "";
                OutputStream os = getContentResolver().openOutputStream(uri, "w");
                if (os == null) return "";
                streams.put(token, os); uris.put(token, uri);
                return token;
            } catch (Exception e) { return ""; }
        }

        @JavascriptInterface
        public void appendDownload(String token, String base64) {
            try {
                OutputStream os = streams.get(token);
                if (os != null) os.write(Base64.decode(base64, Base64.DEFAULT));
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void finishDownload(String token) {
            try {
                OutputStream os = streams.remove(token);
                Uri uri = uris.remove(token);
                if (os != null) { os.flush(); os.close(); }
                if (uri != null) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(uri, values, null, null);
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Saved to Downloads / Submittal Studio", Toast.LENGTH_LONG).show());
                }
            } catch (Exception ignored) {}
        }
    }
}
