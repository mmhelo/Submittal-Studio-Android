const { PDFDocument, StandardFonts, rgb, PDFName, PDFString, PDFHexString } = PDFLib;
const $ = id => document.getElementById(id);
if (window.pdfjsLib) pdfjsLib.GlobalWorkerOptions.workerSrc = 'vendor/pdf.worker.min.js';

const DEFAULT_SECTIONS = [
  ['A','Project Administration'],['B','Technical Specifications & Compliance'],['C','Engineering Drawings'],
  ['D','Calculations / Protection / Communication'],['E','Equipment Catalogues'],['F','Testing & Quality'],
  ['G','Installation / O&M'],['H','Spare Parts / Tools / Warranty'],['I','Certificates & References'],
  ['J','Manufacturing / Delivery Records']
];
const state = {
  docs: [], stamp: null,
  defaultSections: DEFAULT_SECTIONS.map(x=>[...x]),
  sections: DEFAULT_SECTIONS.map(x=>[...x]),
  structure: {
    enabled:false, mode:'strict', fileName:'', fileType:'', items:[], sections:[], rawText:'', applied:false
  }
};
const fieldIds=['projectName','projectCode','location','client','consultant','contractor','vendor','documentTitle','documentNo','revision','issueStatus','issueDate','preparedBy','approvedBy'];

function esc(s=''){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
function fileMB(n){return (n/1024/1024).toFixed(1)+' MB';}
function today(){return new Date().toISOString().slice(0,10);}
function cloneDefaults(){return DEFAULT_SECTIONS.map(x=>[...x]);}
function cloneSectionList(list){return (list||[]).map(x=>[...x]);}
function syncDefaultSections(){if(!(state.structure.enabled&&state.structure.applied))state.defaultSections=cloneSectionList(state.sections);}
function cleanWhitespace(s=''){return String(s).replace(/\s+/g,' ').trim();}
function norm(s=''){return cleanWhitespace(String(s).toLowerCase().replace(/[^a-z0-9]+/g,' '));}
function sectionName(code){return (state.sections.find(x=>x[0]===code)||[])[1]||code;}
function unique(arr){return [...new Set(arr.filter(Boolean))];}
$('issueDate').value=today();

function alphaCode(n){
  let out=''; n=Math.max(1,n);
  while(n>0){n--;out=String.fromCharCode(65+(n%26))+out;n=Math.floor(n/26);}
  return out;
}
function nextSectionCode(){
  const used=new Set(state.sections.map(x=>String(x[0]||'').toUpperCase()));
  for(let n=1;n<703;n++){const code=alphaCode(n);if(!used.has(code))return code;}
  return `S${state.sections.length+1}`;
}
function moveSection(index,delta){
  const to=index+delta;if(to<0||to>=state.sections.length)return;
  [state.sections[index],state.sections[to]]=[state.sections[to],state.sections[index]];
  initSections();renderDocs();syncDefaultSections();saveLocal();
}
function removeSection(index){
  if(state.sections.length<=1){alert('At least one section is required.');return;}
  const [code,name]=state.sections[index];
  const assigned=state.docs.filter(d=>d.section===code);
  if(assigned.length){alert(`Section ${code} – ${name} still contains ${assigned.length} document(s). Reassign those documents before deleting the section.`);return;}
  if(!confirm(`Delete Section ${code} – ${name}?`))return;
  state.sections.splice(index,1);initSections();renderDocs();syncDefaultSections();saveLocal();
}
function addSection(){
  const code=nextSectionCode();state.sections.push([code,`New Section ${code}`]);
  initSections();renderDocs();syncDefaultSections();saveLocal();
  const inputs=$('sectionsEditor').querySelectorAll('.section-name-input');
  const last=inputs[inputs.length-1];if(last){last.focus();last.select();last.scrollIntoView({behavior:'smooth',block:'center'});}
}
function initSections(){
  $('sectionsEditor').innerHTML='';
  state.sections.forEach(([code,name],i)=>{
    const el=document.createElement('div'); el.className='section-edit';
    el.innerHTML=`<div class="section-code">${esc(code)}</div><input class="section-name-input" value="${esc(name)}" data-section-index="${i}" aria-label="Section ${esc(code)} name"><div class="section-controls"><button class="section-mini-btn up" type="button" title="Move section up" ${i===0?'disabled':''}>↑</button><button class="section-mini-btn down" type="button" title="Move section down" ${i===state.sections.length-1?'disabled':''}>↓</button><button class="section-mini-btn delete" type="button" title="Delete unused section">×</button></div>`;
    el.querySelector('.section-name-input').addEventListener('input',e=>{state.sections[i][1]=e.target.value;renderDocs();syncDefaultSections();saveLocal();});
    el.querySelector('.up').onclick=()=>moveSection(i,-1);
    el.querySelector('.down').onclick=()=>moveSection(i,1);
    el.querySelector('.delete').onclick=()=>removeSection(i);
    $('sectionsEditor').appendChild(el);
  });
}
$('addSectionBtn').onclick=addSection;
$('resetSectionsBtn').onclick=()=>{
  const customCodes=new Set(state.sections.map(x=>x[0]).filter(c=>!DEFAULT_SECTIONS.some(d=>d[0]===c)));
  const impacted=state.docs.filter(d=>customCodes.has(d.section));
  if(impacted.length){alert(`Cannot reset yet: ${impacted.length} document(s) are assigned to added sections. Reassign them first.`);return;}
  if(!confirm('Reset section names and order to the default A–J structure?'))return;
  state.sections=cloneDefaults();state.defaultSections=cloneDefaults();initSections();renderDocs();saveLocal();
};
initSections();

function classify(name){
  const n=name.toLowerCase();
  if(/cover|transmittal|register|lod|index|reference sheet|executive/.test(n)) return 'A';
  if(/specification|datasheet|data sheet|compliance|deviation|technical offer/.test(n)) return 'B';
  if(/drawing|ga\b|general arrangement|outline|civil|foundation|nameplate|name plate|schematic|wiring|diagram|layout/.test(n)) return 'C';
  if(/calculation|mapping|architecture|communication|ct\b|vt\b|selectivity|discrimination/.test(n)) return 'D';
  if(/catalog|catalogue|breaker|mccb|acb|relay|meter|component|bom|bill of material/.test(n)) return 'E';
  if(/itp|fat|sat|test procedure|type test|inspection|calibration|mtc/.test(n)) return 'F';
  if(/manual|operation|maintenance|installation|storage|preservation|commissioning|training/.test(n)) return 'G';
  if(/spare|spir|warranty|special tool|consumable/.test(n)) return 'H';
  if(/iso|certificate|approval|reference project|country of origin|prequal/.test(n)) return 'I';
  if(/delivery|packing|dossier|release note|shock|tilt/.test(n)) return 'J';
  return 'B';
}
function cleanTitle(name){return name.replace(/\.pdf$/i,'').replace(/[_-]+/g,' ').replace(/\s+/g,' ').trim();}
function inferRef(name){
  const base=name.replace(/\.pdf$/i,'');
  const m=base.match(/\b(?:[A-Z0-9]{2,}[-_]){1,}[A-Z0-9]{2,}\b/i);
  return m?m[0].replace(/_/g,'-'):'';
}

async function addPDF(file, displayName=file.name){
  const bytes=await file.arrayBuffer();
  let pages=0, err='';
  try{const pdf=await PDFDocument.load(bytes,{ignoreEncryption:true}); pages=pdf.getPageCount();}catch(e){err='Could not read PDF';}
  state.docs.push({
    id:crypto.randomUUID(),file,bytes,name:displayName,title:cleanTitle(displayName),projectRef:'',ref:inferRef(displayName),rev:'',
    section:classify(displayName),pages,size:file.size,include:!err,error:err,structureItemId:null,matchStatus:'default',structureOrder:null
  });
}
async function handleFiles(files){
  setProgress(true,'Reading files...',3);
  const list=[...files];
  for(let i=0;i<list.length;i++){
    const f=list[i]; updateProgress(`Reading ${f.name}`,Math.round((i/Math.max(1,list.length))*35));
    if(/\.zip$/i.test(f.name)||f.type==='application/zip'){
      const zip=await JSZip.loadAsync(await f.arrayBuffer());
      const pdfEntries=Object.values(zip.files).filter(x=>!x.dir&&/\.pdf$/i.test(x.name));
      for(const ent of pdfEntries){
        const blob=await ent.async('blob'); const pf=new File([blob],ent.name.split('/').pop(),{type:'application/pdf'}); await addPDF(pf,ent.name);
      }
    } else if(/\.pdf$/i.test(f.name)||f.type==='application/pdf') await addPDF(f);
  }
  if(state.structure.enabled&&state.structure.items.length) runMatching(false);
  renderDocs(); renderStructurePreview(); saveLocal(); setProgress(false); scrollToId('documents');
}

const dz=$('dropzone'); dz.addEventListener('click',()=>$('fileInput').click());
$('fileInput').addEventListener('change',e=>handleFiles(e.target.files));
['dragenter','dragover'].forEach(ev=>dz.addEventListener(ev,e=>{e.preventDefault();dz.classList.add('dragover')}));
['dragleave','drop'].forEach(ev=>dz.addEventListener(ev,e=>{e.preventDefault();dz.classList.remove('dragover')}));
dz.addEventListener('drop',e=>handleFiles(e.dataTransfer.files));

function renderDocs(){
  const body=$('docsBody'); body.innerHTML='';
  state.docs.forEach(d=>{
    const tr=document.createElement('tr'); tr.draggable=true; tr.dataset.id=d.id;
    const matchLabel=d.matchStatus==='matched'?'Matched to checklist':d.matchStatus==='unassigned'?'Unassigned':d.matchStatus==='suggested'?'Suggested additional':'Automatic';
    const matchClass=d.matchStatus==='matched'?'matched':d.matchStatus==='unassigned'?'unassigned':'default';
    tr.innerHTML=`<td class="drag-handle">⋮⋮</td><td><input type="checkbox" class="inc" ${d.include?'checked':''}></td>
      <td><select class="sec">${state.sections.map(([c,n])=>`<option value="${esc(c)}" ${c===d.section?'selected':''}>${esc(c)} – ${esc(n)}</option>`).join('')}</select></td>
      <td><input class="ttl" value="${esc(d.title)}"></td><td><input class="pref" value="${esc(d.projectRef||'')}"></td>
      <td><input class="ref" value="${esc(d.ref)}"></td><td><input class="rev" value="${esc(d.rev)}"></td>
      <td>${d.pages||'—'}${d.error?'<br><span style="color:#c83434">Unreadable</span>':''}</td>
      <td><span class="match-badge ${matchClass}">${esc(matchLabel)}</span></td>
      <td title="${esc(d.name)}">${esc(d.name.split('/').pop())}</td><td><button class="icon-btn del">✕</button></td>`;
    tr.querySelector('.inc').onchange=e=>{d.include=e.target.checked;updateReadiness();saveLocal();};
    tr.querySelector('.sec').onchange=e=>d.section=e.target.value;
    tr.querySelector('.ttl').oninput=e=>d.title=e.target.value;
    tr.querySelector('.pref').oninput=e=>d.projectRef=e.target.value;
    tr.querySelector('.ref').oninput=e=>d.ref=e.target.value;
    tr.querySelector('.rev').oninput=e=>d.rev=e.target.value;
    tr.querySelector('.del').onclick=()=>{
      state.docs=state.docs.filter(x=>x.id!==d.id);
      state.structure.items.forEach(it=>{if(it.matchedDocId===d.id){it.matchedDocId=null;it.manual=false;}});
      if(state.structure.enabled&&state.structure.items.length) runMatching(false);
      renderDocs();renderStructurePreview();saveLocal();
    };
    [tr.querySelector('.inc'),tr.querySelector('.sec'),tr.querySelector('.ttl'),tr.querySelector('.pref'),tr.querySelector('.ref'),tr.querySelector('.rev')].forEach(x=>x.addEventListener('change',saveLocal));
    tr.addEventListener('dragstart',e=>{e.dataTransfer.setData('text/plain',d.id);tr.style.opacity=.45}); tr.addEventListener('dragend',()=>tr.style.opacity=1);
    tr.addEventListener('dragover',e=>e.preventDefault()); tr.addEventListener('drop',e=>{
      e.preventDefault(); const sid=e.dataTransfer.getData('text/plain'); const from=state.docs.findIndex(x=>x.id===sid); const to=state.docs.findIndex(x=>x.id===d.id);
      if(from<0||to<0||from===to)return; const [mv]=state.docs.splice(from,1); state.docs.splice(to,0,mv); renderDocs();saveLocal();
    });
    body.appendChild(tr);
  });
  const inc=state.docs.filter(x=>x.include); $('docCount').textContent=`${inc.length} documents`; $('pageCount').textContent=`${inc.reduce((s,x)=>s+x.pages,0)} pages`; $('fileSize').textContent=fileMB(inc.reduce((s,x)=>s+x.size,0));
  updateReadiness();
}
$('clearDocsBtn').onclick=()=>{if(confirm('Remove all uploaded documents from this draft?')){state.docs=[];state.structure.items.forEach(it=>{it.matchedDocId=null;it.manual=false});renderDocs();renderStructurePreview();saveLocal();}};
$('autoClassifyBtn').onclick=()=>{state.docs.forEach(d=>{d.section=classify(d.name);d.matchStatus='default';d.structureItemId=null;d.structureOrder=null});renderDocs();saveLocal();};
$('sortSectionBtn').onclick=()=>{state.docs.sort((a,b)=>a.section.localeCompare(b.section)||a.title.localeCompare(b.title));renderDocs();saveLocal();};

// ---------------- CHECKLIST / INDEX PARSING ----------------
function detectSectionMarker(text){
  const s=cleanWhitespace(text);
  let m=s.match(/^SECTION\s+([A-Z0-9]+)\s*[-–—:]?\s*(.+)$/i); if(m)return {code:m[1].toUpperCase(),name:cleanWhitespace(m[2])};
  m=s.match(/^([A-Z])\s*[-–—:]\s*([A-Z][A-Za-z0-9 &/(),.-]{3,})$/); if(m)return {code:m[1].toUpperCase(),name:cleanWhitespace(m[2])};
  return null;
}
function deriveSectionFromSequence(seq=''){
  const s=String(seq).trim(); const m=s.match(/^([A-Z])(?:\d|[.\-]|$)/i); return m?m[1].toUpperCase():'';
}
function looksLikeDocNo(s=''){
  const t=cleanWhitespace(s); if(!t||t.length<4)return false;
  return /\d/.test(t)&&(/[A-Z]/i.test(t))&&(/[-_/]/.test(t))&&t.length>=7;
}
function normalizeHeader(s=''){return norm(s).replace(/\bno\b/g,'number').replace(/\bdoc\b/g,'document');}
function headerIndex(headers,patterns){
  const hs=headers.map(normalizeHeader); for(let i=0;i<hs.length;i++) if(patterns.some(p=>hs[i].includes(p))) return i; return -1;
}
function detectItemsFromRows(rows, source=''){
  const cleanRows=rows.map(r=>(Array.isArray(r)?r:[r]).map(x=>cleanWhitespace(x))).filter(r=>r.some(Boolean));
  if(!cleanRows.length)return {items:[],sections:[]};
  let header=-1, map={};
  for(let i=0;i<Math.min(30,cleanRows.length);i++){
    const r=cleanRows[i]; const h=r.map(normalizeHeader);
    const title=headerIndex(r,['document name','document title','title','description','deliverable','document']);
    const docNo=headerIndex(r,['document number','drawing number','document code','document id','doc number','code']);
    const seq=headerIndex(r,['serial','sequence','sn','item number','item no','id']);
    const rev=headerIndex(r,['revision','rev']);
    const sec=headerIndex(r,['section','group','classification','category','discipline']);
    if(title>=0 && (docNo>=0||seq>=0||sec>=0||h.length<=4)){header=i;map={title,docNo,seq,rev,sec};break;}
  }
  const items=[], sections=[]; let currentSection=null;
  if(header>=0){
    for(let i=header+1;i<cleanRows.length;i++){
      const r=cleanRows[i]; if(!r.some(Boolean))continue;
      const joined=cleanWhitespace(r.join(' ')); const sm=detectSectionMarker(joined);
      if(sm && r.filter(Boolean).length<=2){currentSection=sm;sections.push(sm);continue;}
      const val=j=>j>=0&&j<r.length?cleanWhitespace(r[j]):'';
      let title=val(map.title), seq=val(map.seq), docNo=val(map.docNo), revision=val(map.rev), secVal=val(map.sec);
      if(!title||/^(document name|document title|title|description|documents included)/i.test(title))continue;
      let sectionCode='',sectionName='';
      if(secVal){const m=detectSectionMarker(secVal)||secVal.match(/^([A-Z])\s*[-–—:]?\s*(.*)$/i); if(m){sectionCode=(m.code||m[1]||'').toUpperCase();sectionName=cleanWhitespace(m.name||m[2]||secVal);}else sectionName=secVal;}
      if(!sectionCode)sectionCode=deriveSectionFromSequence(seq);
      if(!sectionCode&&currentSection)sectionCode=currentSection.code;
      if(!sectionName&&currentSection&&sectionCode===currentSection.code)sectionName=currentSection.name;
      if(!sectionCode)sectionCode='A'; if(!sectionName)sectionName=sectionCode==='A'?'Checklist Documents':`Section ${sectionCode}`;
      items.push({id:crypto.randomUUID(),sequence:seq||String(items.length+1),sectionCode,sectionName,title,docNo,revision,classification:secVal,matchedDocId:null,manual:false,score:0,source});
      sections.push({code:sectionCode,name:sectionName});
    }
  }
  if(items.length)return {items,sections:dedupeSections(sections)};
  return detectItemsFromText(cleanRows.map(r=>r.join('   ')).join('\n'),source);
}
function detectItemsFromText(text,source=''){
  const lines=String(text).split(/\r?\n/).map(cleanWhitespace).filter(Boolean); const items=[], sections=[]; let current={code:'A',name:'Checklist Documents'}; sections.push(current);
  for(let i=0;i<lines.length;i++){
    const line=lines[i]; const marker=detectSectionMarker(line); if(marker){current=marker;sections.push(current);continue;}
    if(line.length<4||/^(page|date|rev|revision|prepared|checked|approved|project|client|contractor)\b/i.test(line))continue;
    let seq='',docNo='',title=line,revision='';
    let m=line.match(/^([A-Z]?\d+(?:\.\d+)*)\s+(.+)$/i); if(m){seq=m[1];title=m[2];}
    const codeMatch=title.match(/\b([A-Z0-9]{2,}(?:[-_/][A-Z0-9]{1,}){2,})\b/i); if(codeMatch&&looksLikeDocNo(codeMatch[1])){docNo=codeMatch[1];title=cleanWhitespace(title.replace(codeMatch[1],''));}
    const revMatch=title.match(/\b(?:REV(?:ISION)?\s*[:.-]?\s*)([A-Z0-9.-]+)\b/i); if(revMatch){revision=revMatch[1];title=cleanWhitespace(title.replace(revMatch[0],''));}
    if(title.length<5)continue;
    const keyword=/datasheet|data sheet|specification|compliance|drawing|calculation|catalog|catalogue|manual|procedure|itp|fat|sat|spare|warranty|certificate|register|index|architecture|mapping|deviation|reference|nameplate|operation|maintenance|installation|delivery|packing/i.test(title);
    if(!seq&&!docNo&&!keyword)continue;
    const sectionCode=deriveSectionFromSequence(seq)||current.code||'A'; const sectionName=current.name||`Section ${sectionCode}`;
    items.push({id:crypto.randomUUID(),sequence:seq||String(items.length+1),sectionCode,sectionName,title,docNo,revision,classification:'',matchedDocId:null,manual:false,score:0,source});
  }
  return {items,sections:dedupeSections(sections)};
}
function dedupeSections(sections){
  const out=[],seen=new Set(); for(const s of sections){const code=(s.code||'').toUpperCase()||String.fromCharCode(65+out.length); if(seen.has(code))continue;seen.add(code);out.push({code,name:cleanWhitespace(s.name)||`Section ${code}`});} return out;
}
async function parsePDFChecklist(bytes,fileName){
  const pdf=await pdfjsLib.getDocument({data:new Uint8Array(bytes)}).promise; const allRows=[]; let raw='';
  for(let p=1;p<=pdf.numPages;p++){
    const page=await pdf.getPage(p), tc=await page.getTextContent(); const groups=[];
    tc.items.forEach(it=>{const x=it.transform[4],y=it.transform[5],txt=cleanWhitespace(it.str);if(!txt)return;let g=groups.find(z=>Math.abs(z.y-y)<2.4);if(!g){g={y,items:[]};groups.push(g)}g.items.push({x,w:it.width||0,txt});});
    groups.sort((a,b)=>b.y-a.y);
    for(const g of groups){g.items.sort((a,b)=>a.x-b.x);const cells=[];let cur='',lastEnd=null;for(const it of g.items){const gap=lastEnd==null?0:it.x-lastEnd;if(gap>22&&cur){cells.push(cur);cur=it.txt}else cur+=(cur?' ':'')+it.txt;lastEnd=it.x+it.w;}if(cur)cells.push(cur);if(cells.length){allRows.push(cells);raw+=cells.join('   ')+'\n';}}
  }
  const res=detectItemsFromRows(allRows,fileName); if(res.items.length)return {...res,raw}; return {...detectItemsFromText(raw,fileName),raw};
}
async function parseDocxChecklist(bytes,fileName){
  const result=await mammoth.convertToHtml({arrayBuffer:bytes}); const doc=new DOMParser().parseFromString(result.value,'text/html'); const rows=[];
  doc.querySelectorAll('table tr').forEach(tr=>rows.push([...tr.querySelectorAll('th,td')].map(td=>cleanWhitespace(td.textContent))));
  const raw=cleanWhitespace(doc.body.innerText||doc.body.textContent||'').replace(/\s*\n\s*/g,'\n');
  if(rows.length){const res=detectItemsFromRows(rows,fileName);if(res.items.length)return {...res,raw};}
  return {...detectItemsFromText(doc.body.innerText||doc.body.textContent||'',fileName),raw};
}
async function parseExcelChecklist(bytes,fileName){
  const wb=XLSX.read(bytes,{type:'array'}); let items=[],sections=[],raw='';
  wb.SheetNames.forEach(name=>{const rows=XLSX.utils.sheet_to_json(wb.Sheets[name],{header:1,defval:'',raw:false}); const r=detectItemsFromRows(rows,`${fileName} / ${name}`);items.push(...r.items);sections.push(...r.sections);raw+=rows.map(x=>x.join(' | ')).join('\n')+'\n';});
  return {items,sections:dedupeSections(sections),raw};
}
async function parseChecklistFile(file){
  const bytes=await file.arrayBuffer(); const name=file.name.toLowerCase();
  if(name.endsWith('.pdf'))return parsePDFChecklist(bytes,file.name);
  if(name.endsWith('.docx'))return parseDocxChecklist(bytes,file.name);
  if(name.endsWith('.xlsx')||name.endsWith('.xls'))return parseExcelChecklist(bytes,file.name);
  throw new Error('Unsupported checklist format. Please use PDF, DOCX, XLSX or XLS.');
}
function tokenSet(s){
  const stop=new Set(['the','and','for','of','to','a','an','technical','material','submittal','document','documents','project','vendor','manufacturer','rev','revision','pdf']);
  return new Set(norm(s).split(' ').filter(x=>x.length>1&&!stop.has(x)));
}
function similarity(a,b){
  const A=tokenSet(a),B=tokenSet(b); if(!A.size||!B.size)return 0; let inter=0;A.forEach(x=>{if(B.has(x))inter++});return (2*inter)/(A.size+B.size);
}
function matchScore(item,doc){
  let score=similarity(item.title,`${doc.title} ${doc.name}`);
  const ino=norm(item.docNo),drefs=norm(`${doc.projectRef} ${doc.ref} ${doc.name}`);
  if(ino&&drefs.includes(ino))score+=1.2; else if(ino&&similarity(item.docNo,`${doc.ref} ${doc.name}`)>.65)score+=.55;
  if(item.sectionCode&&doc.section===item.sectionCode)score+=.08;
  return score;
}
function runMatching(preserveManual=true){
  if(!state.structure.items.length)return;
  const validIds=new Set(state.docs.map(d=>d.id));
  state.structure.items.forEach(it=>{if(!validIds.has(it.matchedDocId)){it.matchedDocId=null;it.manual=false;}if(!preserveManual||!it.manual){it.matchedDocId=null;it.score=0;it.manual=false;}});
  const used=new Set(state.structure.items.filter(it=>it.manual&&it.matchedDocId).map(it=>it.matchedDocId));
  state.structure.items.forEach(it=>{
    if(it.manual&&it.matchedDocId)return;
    let best=null,bestScore=0; for(const d of state.docs){if(used.has(d.id)||d.error)continue;const s=matchScore(it,d);if(s>bestScore){best=d;bestScore=s;}}
    if(best&&bestScore>=.34){it.matchedDocId=best.id;it.score=bestScore;used.add(best.id);}else{it.matchedDocId=null;it.score=bestScore;}
  });
  renderStructurePreview();
}
function getUnassignedDocs(){const used=new Set(state.structure.items.map(i=>i.matchedDocId).filter(Boolean));return state.docs.filter(d=>!used.has(d.id)&&!d.error);}
function renderStructurePreview(){
  const has=state.structure.enabled&&state.structure.items.length; $('detectedPreview').classList.toggle('hidden',!has); if(!has)return;
  const items=state.structure.items, matched=items.filter(i=>i.matchedDocId).length, missing=items.length-matched, unassigned=getUnassignedDocs();
  $('detectedCount').textContent=items.length;$('matchedCount').textContent=matched;$('missingCount').textContent=missing;$('unassignedCount').textContent=unassigned.length;
  const body=$('structureBody');body.innerHTML='';
  items.forEach(it=>{
    const tr=document.createElement('tr');tr.className=it.matchedDocId?'row-matched':'row-missing';
    const options=['<option value="">— Not matched —</option>',...state.docs.filter(d=>!d.error).map(d=>`<option value="${d.id}" ${d.id===it.matchedDocId?'selected':''}>${esc(d.title)} · ${esc(d.name.split('/').pop())}</option>`)].join('');
    const status=it.matchedDocId?`<span class="match-badge matched">Matched${it.score?` · ${Math.min(99,Math.round(it.score*70))}%`:''}</span>`:'<span class="match-badge unassigned">Missing / Not Uploaded</span>';
    tr.innerHTML=`<td>${esc(it.sequence)}</td><td><strong>${esc(it.sectionCode)}</strong><br><span class="muted">${esc(it.sectionName)}</span></td><td>${esc(it.title)}</td><td>${esc(it.docNo||'—')}</td><td>${esc(it.revision||'—')}</td><td><select class="manual-match">${options}</select></td><td>${status}</td>`;
    tr.querySelector('.manual-match').onchange=e=>{it.matchedDocId=e.target.value||null;it.manual=true;it.score=0;runMatching(true);saveLocal();};body.appendChild(tr);
  });
  $('unassignedBox').classList.toggle('hidden',!unassigned.length); if(unassigned.length)$('unassignedBox').innerHTML=`<strong>Unassigned Documents – Review Required</strong><div class="unassigned-list">${unassigned.map(d=>`<span class="mini-badge">${esc(d.title)}</span>`).join('')}</div>`;
}
function applyDetectedStructure(){
  if(!state.structure.items.length)return;
  const sections=dedupeSections(state.structure.sections.length?state.structure.sections:state.structure.items.map(i=>({code:i.sectionCode,name:i.sectionName})));
  const usedCodes=new Set(sections.map(s=>s.code)); if(!sections.length)sections.push({code:'A',name:'Checklist Documents'});
  const unassigned=getUnassignedDocs(); if(unassigned.length&&!usedCodes.has('U'))sections.push({code:'U',name:state.structure.mode==='strict'?'Unassigned Documents – Review Required':'Suggested Additional Documents'});
  state.sections=sections.map(s=>[s.code,s.name]);
  const order=new Map();state.structure.items.forEach((it,i)=>{if(it.matchedDocId)order.set(it.matchedDocId,i);const d=state.docs.find(x=>x.id===it.matchedDocId);if(d){d.section=it.sectionCode;d.title=it.title;d.projectRef=it.docNo||d.projectRef;d.rev=it.revision||d.rev;d.structureItemId=it.id;d.structureOrder=i;d.matchStatus='matched';}});
  unassigned.forEach((d,i)=>{d.section='U';d.structureItemId=null;d.structureOrder=100000+i;d.matchStatus=state.structure.mode==='strict'?'unassigned':'suggested';});
  state.docs.sort((a,b)=>(a.structureOrder??999999)-(b.structureOrder??999999)); state.structure.applied=true; initSections();renderDocs();renderStructurePreview();updateStructureModeUI();saveLocal();scrollToId('documents');
}

function setChecklistEnabled(enabled){
  state.structure.enabled=enabled; $('checklistPanel').classList.toggle('hidden',!enabled); $('defaultStructureBlock').classList.toggle('hidden',enabled&&state.structure.applied);
  $('structureStatus').textContent=enabled&&state.structure.applied?'CLIENT STRUCTURE':'ACTIVE'; $('structureStatus').classList.toggle('client',enabled&&state.structure.applied);
  document.querySelectorAll('.choice-card').forEach(c=>c.classList.toggle('selected',c.querySelector('input').checked));
  if(!enabled){state.structure.applied=false;state.sections=cloneSectionList(state.defaultSections?.length?state.defaultSections:cloneDefaults());state.docs.forEach(d=>{if(!state.sections.some(([c])=>c===d.section))d.section=classify(d.name);d.projectRef='';d.structureItemId=null;d.structureOrder=null;d.matchStatus='default'});initSections();renderDocs();}
  saveLocal(); updateReadiness();
}
function updateStructureModeUI(){
  $('structureStatus').textContent=state.structure.enabled&&state.structure.applied?'CLIENT STRUCTURE':'ACTIVE'; $('structureStatus').classList.toggle('client',state.structure.enabled&&state.structure.applied);
  $('defaultStructureBlock').classList.toggle('hidden',state.structure.enabled&&state.structure.applied);
}
document.querySelectorAll('input[name="hasChecklist"]').forEach(r=>r.onchange=e=>setChecklistEnabled(e.target.value==='yes'));
$('checklistMode').onchange=e=>{state.structure.mode=e.target.value;runMatching(true);saveLocal();};
$('checklistInput').onchange=async e=>{
  const f=e.target.files[0];if(!f)return;state.structure.fileName=f.name;state.structure.fileType=f.type;state.structure.applied=false;$('checklistName').textContent=f.name;$('checklistParseStatus').textContent='Reading structure locally...';setProgress(true,'Reading checklist / index...',4);
  try{const parsed=await parseChecklistFile(f);state.structure.items=parsed.items;state.structure.sections=parsed.sections;state.structure.rawText=parsed.raw||'';runMatching(false);$('checklistParseStatus').textContent=`Detected ${parsed.items.length} document item${parsed.items.length===1?'':'s'} across ${parsed.sections.length||1} section${parsed.sections.length===1?'':'s'}. Review before applying.`;if(!parsed.items.length)throw new Error('No document rows were confidently detected. Try an Excel register or a cleaner PDF/DOCX index.');}
  catch(err){console.error(err);state.structure.items=[];state.structure.sections=[];$('checklistParseStatus').textContent='Could not detect a usable document structure: '+(err.message||err);renderStructurePreview();}
  setProgress(false);saveLocal();
};
$('rerunMatchBtn').onclick=()=>{runMatching(false);saveLocal();};
$('applyStructureBtn').onclick=applyDetectedStructure;

// ---------------- PROJECT / SETTINGS ----------------
function project(){return Object.fromEntries(fieldIds.map(id=>[id,$(id).value.trim()]));}
fieldIds.forEach(id=>$(id).addEventListener('input',()=>{saveLocal();updateReadiness()}));
function updateReadiness(){
  const p=project(), n=state.docs.filter(d=>d.include&&!d.error).length, missing=[];if(!p.projectName)missing.push('project name');if(!p.documentTitle)missing.push('document title');if(!p.documentNo)missing.push('document number');if(!n)missing.push('documents');
  let extra='';if(state.structure.enabled&&state.structure.items.length){const miss=state.structure.items.filter(i=>!i.matchedDocId).length,un=getUnassignedDocs().filter(d=>d.include).length;extra=` Checklist review: ${miss} missing, ${un} unassigned.`;}
  $('readinessText').textContent=missing.length?`Missing: ${missing.join(', ')}.${extra}`:`Ready: ${n} documents selected for packaging.${extra}`;
}
$('stampInput').onchange=async e=>{const f=e.target.files[0];if(!f)return;state.stamp={name:f.name,type:f.type,bytes:await f.arrayBuffer()};$('stampName').textContent=f.name;};
function serializable(){return {project:project(),sections:state.sections,defaultSections:state.defaultSections,structure:{...state.structure,rawText:''},docs:state.docs.map(({bytes,file,...d})=>d)};}
function saveLocal(){try{localStorage.setItem('submittal-studio-draft-v2',JSON.stringify({project:project(),sections:state.sections,defaultSections:state.defaultSections,structure:{...state.structure,rawText:'',items:state.structure.items.map(i=>({...i,matchedDocId:null,manual:false}))}}));}catch(e){}}
$('saveDraftBtn').onclick=()=>{saveLocal();alert('Draft settings saved in this browser. Uploaded file bytes are not stored for privacy; re-upload files after reopening.')};
async function downloadBlob(blob,name){
  if(window.Android && typeof Android.beginDownload==='function'){
    try{
      const token=Android.beginDownload(name,blob.type||'application/octet-stream');
      if(token){
        const bytes=new Uint8Array(await blob.arrayBuffer()),CHUNK=49152;
        for(let i=0;i<bytes.length;i+=CHUNK){let binary='';const end=Math.min(i+CHUNK,bytes.length);for(let j=i;j<end;j++)binary+=String.fromCharCode(bytes[j]);Android.appendDownload(token,btoa(binary));}
        Android.finishDownload(token);return;
      }
    }catch(err){console.warn('Android save fallback',err);}
  }
  const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},2500);
}
$('exportConfigBtn').onclick=()=>downloadBlob(new Blob([JSON.stringify(serializable(),null,2)],{type:'application/json'}),'submittal-config-v2.json');
$('importConfigInput').onchange=async e=>{const f=e.target.files[0];if(!f)return;const j=JSON.parse(await f.text());if(j.project)fieldIds.forEach(id=>{if(j.project[id]!=null)$(id).value=j.project[id]});if(j.defaultSections)state.defaultSections=cloneSectionList(j.defaultSections);if(j.sections)state.sections=cloneSectionList(j.sections);else if(j.defaultSections)state.sections=cloneSectionList(j.defaultSections);if(j.structure){state.structure={...state.structure,...j.structure};state.structure.enabled=!!j.structure.enabled;}initSections();document.querySelector(`input[name="hasChecklist"][value="${state.structure.enabled?'yes':'no'}"]`).checked=true;setChecklistEnabled(state.structure.enabled);$('checklistMode').value=state.structure.mode||'strict';alert('Configuration imported. Please re-upload the source PDFs/ZIPs and the checklist file to attach file contents.');saveLocal();updateReadiness();};

function scrollToId(id){document.getElementById(id).scrollIntoView({behavior:'smooth',block:'start'});document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.target===id));}
document.querySelectorAll('.nav-item').forEach(b=>b.onclick=()=>scrollToId(b.dataset.target));
function setProgress(show,text='',pct=0){$('progressWrap').classList.toggle('hidden',!show);if(show)updateProgress(text,pct);}
function updateProgress(text,pct){$('progressText').textContent=text;$('progressPct').textContent=`${pct}%`;$('progressBar').style.width=`${Math.max(0,Math.min(100,pct))}%`;}
function containsRTL(text){return /[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFF]/.test(String(text||''));}
function canvasMeasure(text,size,weight='400'){const c=document.createElement('canvas'),ctx=c.getContext('2d'),scale=4;ctx.font=`${weight} ${size*scale}px Arial, Tahoma, "Segoe UI", sans-serif`;return ctx.measureText(String(text||'')).width/scale;}
function measureTextWidth(text,font,size,weight='400'){try{return font.widthOfTextAtSize(String(text||''),size)}catch(e){return canvasMeasure(text,size,weight)}}
function wrapText(text,font,size,maxWidth,weight='400'){const words=String(text||'—').split(/\s+/);const lines=[];let line='';for(const w of words){const t=line?line+' '+w:w;if(measureTextWidth(t,font,size,weight)<=maxWidth)line=t;else{if(line)lines.push(line);line=w;}}if(line)lines.push(line);return lines.length?lines:['—'];}
function colorCss(c,fallback='#17212b'){if(!c)return fallback;try{const r=Math.round((c.red??c.r??0)*255),g=Math.round((c.green??c.g??0)*255),b=Math.round((c.blue??c.b??0)*255);return `rgb(${r},${g},${b})`}catch(e){return fallback}}
async function drawTextSmart(pdf,page,text,opts={}){text=String(text??'—');try{page.drawText(text,opts);return {width:opts.font?measureTextWidth(text,opts.font,opts.size||12,opts.weight||'400'):0};}catch(err){const msg=String(err&&err.message||err);if(!/WinAnsi|cannot encode|encoding/i.test(msg))throw err;}const size=opts.size||12,scale=4,weight=opts.weight||'400',pad=4*scale,rtl=containsRTL(text);let canvas=document.createElement('canvas'),ctx=canvas.getContext('2d');ctx.font=`${weight} ${size*scale}px Arial, Tahoma, "Segoe UI", sans-serif`;const measured=ctx.measureText(text).width;canvas.width=Math.max(8,Math.ceil(measured+pad*2));canvas.height=Math.max(8,Math.ceil(size*1.65*scale+pad*2));ctx=canvas.getContext('2d');ctx.font=`${weight} ${size*scale}px Arial, Tahoma, "Segoe UI", sans-serif`;ctx.direction=rtl?'rtl':'ltr';ctx.textAlign=rtl?'right':'left';ctx.textBaseline='alphabetic';ctx.fillStyle=opts.cssColor||colorCss(opts.color);const tx=rtl?canvas.width-pad:pad,ty=pad+size*scale*1.12;ctx.fillText(text,tx,ty);const cache=pdf.__unicodeImageCache||(pdf.__unicodeImageCache=new Map()),key=[text,size,weight,ctx.fillStyle].join('|');let img=cache.get(key);if(!img){img=await pdf.embedPng(canvas.toDataURL('image/png'));cache.set(key,img);}const w=canvas.width/scale,h=canvas.height/scale;page.drawImage(img,{x:opts.x||0,y:(opts.y||0)-size*.36,width:w,height:h});return {width:w,height:h};}
async function drawLinesSmart(pdf,page,lines,x,y,font,size,color,leading,weight='400',cssColor){for(let i=0;i<lines.length;i++)await drawTextSmart(pdf,page,lines[i],{x,y:y-i*leading,font,size,color,weight,cssColor});}
function pdfTextString(text){const s=String(text??'');try{return PDFHexString&&PDFHexString.fromText?PDFHexString.fromText(s):PDFString.of(s)}catch(e){return PDFString.of(s.replace(/[^\x20-\x7E]/g,'?'))}}
function addGoTo(pdf,page,rect,targetIndex){
  if(!Number.isInteger(targetIndex)||targetIndex<0||targetIndex>=pdf.getPageCount())return;
  const dest=pdf.context.obj([pdf.getPage(targetIndex).ref,PDFName.of('Fit')]); const annots=page.node.lookupMaybe(PDFName.of('Annots'),PDFLib.PDFArray)||pdf.context.obj([]);page.node.set(PDFName.of('Annots'),annots);
  const annot=pdf.context.obj({Type:PDFName.of('Annot'),Subtype:PDFName.of('Link'),Rect:[rect.x,rect.y,rect.x+rect.w,rect.y+rect.h],Border:[0,0,0],Dest:dest});annots.push(pdf.context.register(annot));
}
async function makeCoverPage(pdf,p,font,bold){
  const page=pdf.addPage([595.28,841.89]),W=page.getWidth(),H=page.getHeight();page.drawRectangle({x:0,y:H-120,width:W,height:120,color:rgb(.02,.35,.58)});page.drawRectangle({x:0,y:0,width:W,height:16,color:rgb(.02,.35,.58)});page.drawText('TECHNICAL MATERIAL SUBMITTAL',{x:42,y:H-70,font:bold,size:22,color:rgb(1,1,1)});await drawTextSmart(pdf,page,p.vendor||'Vendor / Manufacturer',{x:42,y:H-96,font,size:11,color:rgb(.88,.95,1),cssColor:'#e0f2ff'});
  let y=H-175;const titleLines=wrapText(p.documentTitle||'Technical Material Submittal',bold,24,W-84,'700');await drawLinesSmart(pdf,page,titleLines,42,y,bold,24,rgb(.05,.14,.2),30,'700','#0d2433');y-=titleLines.length*30+20;
  const info=[['PROJECT',p.projectName],['DOCUMENT NO.',p.documentNo],['REVISION',p.revision],['STATUS',p.issueStatus],['END USER / CLIENT',p.client],['OWNER ENGINEER / CONSULTANT',p.consultant],['EPC CONTRACTOR',p.contractor],['LOCATION',p.location],['DATE',p.issueDate]];
  for(const [k,v] of info){page.drawText(k,{x:42,y,font:bold,size:8,color:rgb(.3,.4,.48)});const ls=wrapText(v||'—',font,10,W-190);await drawLinesSmart(pdf,page,ls,155,y,font,10,rgb(.08,.16,.22),13,'400','#142938');page.drawLine({start:{x:42,y:y-8},end:{x:W-42,y:y-8},thickness:.5,color:rgb(.82,.86,.89)});y-=Math.max(31,ls.length*13+15)}
  page.drawRectangle({x:42,y:56,width:W-84,height:62,color:rgb(.95,.97,.985),borderColor:rgb(.82,.87,.91),borderWidth:.7});await drawLinesSmart(pdf,page,wrapText('Controlled engineering submission: the project document number governs the complete package; manufacturer internal references are retained for full technical traceability.',font,9,W-112),56,94,font,9,rgb(.23,.32,.39),12);
}
function rowHeight(title,font){return Math.max(26,wrapText(title,font,8.4,244).length*11+8);}
function buildIndexEntries(){
  const docsById=new Map(state.docs.map(d=>[d.id,d]));
  if(state.structure.enabled&&state.structure.items.length){
    const entries=state.structure.items.map((it,i)=>{const d=docsById.get(it.matchedDocId);return {key:it.id,sequence:it.sequence||`${it.sectionCode}${i+1}`,section:it.sectionCode,sectionName:it.sectionName,title:it.title,projectRef:it.docNo||d?.projectRef||'',manufacturerRef:d?.ref||'',rev:it.revision||d?.rev||'',status:d&&d.include&&!d.error?'Included':'Missing / Not Uploaded',doc:d&&d.include&&!d.error?d:null};});
    const used=new Set(state.structure.items.map(i=>i.matchedDocId).filter(Boolean));const extras=state.docs.filter(d=>d.include&&!d.error&&!used.has(d.id));
    extras.forEach((d,i)=>entries.push({key:`u-${d.id}`,sequence:`U${i+1}`,section:'U',sectionName:state.structure.mode==='strict'?'Unassigned Documents – Review Required':'Suggested Additional Documents',title:d.title,projectRef:d.projectRef||'',manufacturerRef:d.ref||'',rev:d.rev||'',status:state.structure.mode==='strict'?'Unassigned – Review Required':'Suggested Additional',doc:d}));
    return entries;
  }
  const counts={};return state.docs.filter(d=>d.include&&!d.error).map(d=>{counts[d.section]=(counts[d.section]||0)+1;return {key:d.id,sequence:`${d.section}${counts[d.section]}`,section:d.section,sectionName:sectionName(d.section),title:d.title,projectRef:d.projectRef||'',manufacturerRef:d.ref||'',rev:d.rev||'',status:'Included',doc:d};});
}
function ensureSectionsForEntries(entries){
  const out=state.sections.map(x=>[...x]);const codes=new Set(out.map(x=>x[0]));for(const e of entries){if(!codes.has(e.section)){out.push([e.section,e.sectionName||`Section ${e.section}`]);codes.add(e.section);}}return out;
}
function addBookmarks(pdf,sectionList,sectionStarts,entries,startsByDocId){
  try{
    const root=pdf.context.obj({Type:PDFName.of('Outlines')});const rootRef=pdf.context.register(root);const top=[];
    for(const [code,name] of sectionList){
      const kids=entries.filter(e=>e.section===code&&e.doc&&Number.isInteger(startsByDocId.get(e.doc.id)));if(!kids.length&&!Number.isInteger(sectionStarts[code]))continue;
      const sec=pdf.context.obj({Title:pdfTextString(`Section ${code} – ${name}`),Parent:rootRef});const secRef=pdf.context.register(sec);const target=Number.isInteger(sectionStarts[code])?sectionStarts[code]:startsByDocId.get(kids[0].doc.id);sec.set(PDFName.of('Dest'),pdf.context.obj([pdf.getPage(target).ref,PDFName.of('Fit')]));
      const childRefs=[];for(const e of kids){const ci=pdf.context.obj({Title:pdfTextString(`${e.sequence} ${e.title}`),Parent:secRef,Dest:pdf.context.obj([pdf.getPage(startsByDocId.get(e.doc.id)).ref,PDFName.of('Fit')])});childRefs.push(pdf.context.register(ci));}
      childRefs.forEach((r,i)=>{const d=pdf.context.lookup(r);if(i)d.set(PDFName.of('Prev'),childRefs[i-1]);if(i<childRefs.length-1)d.set(PDFName.of('Next'),childRefs[i+1]);});if(childRefs.length){sec.set(PDFName.of('First'),childRefs[0]);sec.set(PDFName.of('Last'),childRefs[childRefs.length-1]);sec.set(PDFName.of('Count'),pdf.context.obj(childRefs.length));}top.push(secRef);
    }
    top.forEach((r,i)=>{const d=pdf.context.lookup(r);if(i)d.set(PDFName.of('Prev'),top[i-1]);if(i<top.length-1)d.set(PDFName.of('Next'),top[i+1]);});if(top.length){root.set(PDFName.of('First'),top[0]);root.set(PDFName.of('Last'),top[top.length-1]);root.set(PDFName.of('Count'),pdf.context.obj(top.length));pdf.catalog.set(PDFName.of('Outlines'),rootRef);pdf.catalog.set(PDFName.of('PageMode'),PDFName.of('UseOutlines'));}
  }catch(e){console.warn('Bookmark creation skipped',e);}
}
async function generatePDF(){
  const p=project(),includedDocs=state.docs.filter(d=>d.include&&!d.error);if(!p.projectName||!p.documentTitle||!p.documentNo||!includedDocs.length){alert('Please complete Project Name, Document Title, Document No. and add at least one readable PDF.');return;}
  if(state.structure.enabled&&state.structure.items.length){const missing=state.structure.items.filter(i=>!i.matchedDocId).length,un=getUnassignedDocs().filter(d=>d.include).length;if((missing||un)&&!confirm(`Checklist review is not fully closed: ${missing} missing item(s), ${un} unassigned document(s). Continue and show these statuses in the final index?`))return;}
  setProgress(true,'Creating controlled package...',2);$('resultBox').classList.add('hidden');
  try{
    const out=await PDFDocument.create(),font=await out.embedFont(StandardFonts.Helvetica),bold=await out.embedFont(StandardFonts.HelveticaBold);await makeCoverPage(out,p,font,bold);updateProgress('Building document register...',8);
    const entries=buildIndexEntries(),sectionList=ensureSectionsForEntries(entries).filter(([c])=>entries.some(e=>e.section===c));const indexStart=1,indexRowsPerPage=18,indexPageCount=Math.max(1,Math.ceil(entries.length/indexRowsPerPage)),indexRows=[];
    for(let ip=0;ip<indexPageCount;ip++){
      const page=out.addPage([841.89,595.28]),W=page.getWidth(),H=page.getHeight();page.drawText(ip===0?'MASTER DOCUMENT REGISTER & INTERACTIVE INDEX':'MASTER INDEX – CONTINUED',{x:24,y:H-31,font:bold,size:15,color:rgb(.02,.31,.51)});await drawTextSmart(out,page,`${p.documentNo} | Rev ${p.revision}${state.structure.enabled&&state.structure.items.length?' | Client structure source active':''}`,{x:24,y:H-48,font,size:8,color:rgb(.36,.43,.49),cssColor:'#5c6e7d'});
      const cols=[24,58,306,452,565,610,690,769],headers=['ID','DOCUMENT TITLE','PROJECT / CHECKLIST REF.','MFR. REF.','REV','STATUS','PAGE','QUICK'];page.drawRectangle({x:24,y:H-77,width:794,height:22,color:rgb(.91,.95,.98)});headers.forEach((h,i)=>page.drawText(h,{x:cols[i]+3,y:H-64,font:bold,size:6.8,color:rgb(.08,.22,.31)}));
      let y=H-99;const slice=entries.slice(ip*indexRowsPerPage,(ip+1)*indexRowsPerPage);for(let j=0;j<slice.length;j++){const e=slice[j],global=ip*indexRowsPerPage+j,h=rowHeight(e.title,font);if(global%2===0)page.drawRectangle({x:24,y:y-h+5,width:794,height:h,color:rgb(.985,.99,.994)});const statColor=e.status==='Included'?rgb(.08,.38,.22):e.status.startsWith('Missing')?rgb(.67,.31,.04):rgb(.55,.36,.02);await drawTextSmart(out,page,String(e.sequence),{x:28,y,font:bold,size:7.6,color:rgb(.02,.38,.64),weight:'700',cssColor:'#0562a3'});await drawLinesSmart(out,page,wrapText(e.title,font,8.2,238),62,y,font,8.2,rgb(.04,.34,.58),10.5,'400','#0a578f');await drawLinesSmart(out,page,wrapText(e.projectRef||'—',font,7.1,138),310,y,font,7.1,rgb(.08,.13,.17),9,'400','#14212b');await drawLinesSmart(out,page,wrapText(e.manufacturerRef||'—',font,7.1,104),456,y,font,7.1,rgb(.08,.13,.17),9,'400','#14212b');await drawTextSmart(out,page,e.rev||'—',{x:569,y,font,size:7.4,color:rgb(.08,.13,.17),cssColor:'#14212b'});await drawLinesSmart(out,page,wrapText(e.status,font,7.1,76),614,y,font,7.1,statColor,8.5,'400',e.status==='Included'?'#146138':e.status.startsWith('Missing')?'#ab4f0a':'#8c5c05');page.drawText(e.doc?'TBD':'—',{x:696,y,font,size:7.4,color:rgb(.08,.13,.17)});page.drawText(e.doc?'OPEN >':'MISSING',{x:772,y,font:bold,size:7.2,color:e.doc?rgb(0,.42,.72):rgb(.7,.25,.12)});page.drawLine({start:{x:24,y:y-h+2},end:{x:818,y:y-h+2},thickness:.35,color:rgb(.84,.88,.91)});indexRows.push({page,entry:e,rect:{x:24,y:y-h+2,w:794,h},pageTextPos:{x:696,y}});y-=h;}page.drawText(`Package index ${ip+1} of ${indexPageCount}`,{x:690,y:14,font,size:7,color:rgb(.45,.5,.54)});
    }
    const startsByDocId=new Map(),sectionStarts={},sourcePages=new Set();let processed=0;const mergeOrder=[];for(const [code,name] of sectionList){const secEntries=entries.filter(e=>e.section===code);if($('optDividers').checked){const pg=out.addPage([595.28,841.89]);sectionStarts[code]=out.getPageCount()-1;pg.drawRectangle({x:0,y:0,width:595.28,height:841.89,color:rgb(.965,.978,.987)});pg.drawRectangle({x:0,y:0,width:18,height:841.89,color:rgb(.02,.38,.63)});pg.drawText(`SECTION ${code}`,{x:55,y:510,font:bold,size:14,color:rgb(.02,.38,.63)});await drawLinesSmart(out,pg,wrapText(name,bold,29,480,'700'),55,465,bold,29,rgb(.06,.15,.21),35,'700','#0f2636');const inc=secEntries.filter(e=>e.doc).length,miss=secEntries.filter(e=>!e.doc).length;pg.drawText(`${inc} included document${inc===1?'':'s'}${miss?` • ${miss} missing / not uploaded`:''}`,{x:55,y:118,font,size:9,color:rgb(.35,.43,.49)});pg.drawText('Controlled engineering submission',{x:55,y:90,font,size:9,color:rgb(.38,.45,.5)});}else sectionStarts[code]=out.getPageCount();
      for(const e of secEntries){if(!e.doc||startsByDocId.has(e.doc.id))continue;mergeOrder.push(e.doc);updateProgress(`Merging ${e.title}`,12+Math.round((processed/Math.max(1,includedDocs.length))*68));const src=await PDFDocument.load(e.doc.bytes,{ignoreEncryption:true});const copied=await out.copyPages(src,src.getPageIndices());const start=out.getPageCount();startsByDocId.set(e.doc.id,start);copied.forEach(pg=>{out.addPage(pg);sourcePages.add(out.getPageCount()-1)});processed++;}
    }
    for(const d of includedDocs){if(startsByDocId.has(d.id))continue;const src=await PDFDocument.load(d.bytes,{ignoreEncryption:true});const copied=await out.copyPages(src,src.getPageIndices());const start=out.getPageCount();startsByDocId.set(d.id,start);copied.forEach(pg=>{out.addPage(pg);sourcePages.add(out.getPageCount()-1)});}
    const total=out.getPageCount();indexRows.forEach(r=>{if(r.entry.doc){const target=startsByDocId.get(r.entry.doc.id);if(Number.isInteger(target)){addGoTo(out,r.page,r.rect,target);r.page.drawRectangle({x:r.pageTextPos.x-1,y:r.pageTextPos.y-2,width:38,height:11,color:rgb(1,1,1)});r.page.drawText(String(target+1),{x:r.pageTextPos.x,y:r.pageTextPos.y,font,size:7.4,color:rgb(.08,.13,.17)});}}});
    let stampImg=null;if(state.stamp){try{stampImg=state.stamp.type.includes('png')?await out.embedPng(state.stamp.bytes):await out.embedJpg(state.stamp.bytes)}catch(e){}}
    updateProgress('Adding bookmarks, navigation and document control...',84);const indexTarget=indexStart;const allPages=out.getPages();for(let i=0;i<allPages.length;i++){const pg=allPages[i],W=pg.getWidth(),H=pg.getHeight();if($('optFooter').checked&&i>0){const fs=Math.max(6,Math.min(8,W/100));pg.drawRectangle({x:0,y:0,width:W,height:18,color:rgb(1,1,1),opacity:.94});pg.drawLine({start:{x:18,y:18},end:{x:W-18,y:18},thickness:.4,color:rgb(.02,.38,.63)});await drawTextSmart(out,pg,`${p.documentNo} | Rev ${p.revision}`,{x:22,y:6,font,size:fs,color:rgb(.25,.31,.36),cssColor:'#404f5c'});const t=`Package Page ${i+1} of ${total}`;pg.drawText(t,{x:W/2-font.widthOfTextAtSize(t,fs)/2,y:6,font,size:fs,color:rgb(.25,.31,.36)});}if($('optBack').checked&&i>indexPageCount){const t='BACK TO INDEX',fs=Math.max(6,Math.min(8,W/100)),tw=bold.widthOfTextAtSize(t,fs),x=W-tw-22;pg.drawText(t,{x,y:6,font:bold,size:fs,color:rgb(0,.39,.68)});addGoTo(out,pg,{x:x-3,y:2,w:tw+6,h:14},indexTarget);}if(stampImg&&sourcePages.has(i)){const maxW=Math.min(95,W*.14),scale=maxW/stampImg.width,sh=stampImg.height*scale;pg.drawImage(stampImg,{x:22,y:24,width:maxW,height:sh,opacity:.82});}}
    addBookmarks(out,sectionList,sectionStarts,entries,startsByDocId);
    if($('optMetadata').checked){out.setTitle(p.documentTitle);out.setAuthor(p.vendor||'Vendor');out.setSubject(`${p.projectName} – ${p.documentNo}`);out.setKeywords(['technical submittal','engineering','document control',p.projectCode||'',p.vendor||'',state.structure.enabled?'client checklist':'automatic structure']);out.setCreator('Submittal Studio V2.5 Unicode');out.setProducer('Submittal Studio V2.5 / pdf-lib');}
    updateProgress('Finalizing PDF...',94);const pdfBytes=await out.save({useObjectStreams:true});const safe=(p.documentNo||'Submittal').replace(/[^A-Za-z0-9_-]+/g,'_');downloadBlob(new Blob([pdfBytes],{type:'application/pdf'}),`${safe}_Rev${p.revision}_FINAL.pdf`);if($('optLodCsv').checked)downloadLOD(entries,startsByDocId,p);updateProgress('Complete',100);$('resultBox').classList.remove('hidden');const miss=entries.filter(e=>e.status.startsWith('Missing')).length,un=entries.filter(e=>e.status.startsWith('Unassigned')).length;$('resultBox').innerHTML=`<strong>Package generated successfully.</strong><br>${includedDocs.length} source documents • ${total} package pages${state.structure.enabled?` • ${miss} missing checklist item(s) • ${un} unassigned item(s)`:''}. Your browser should have started the PDF${$('optLodCsv').checked?' and LOD CSV':''} download.`;
  }catch(e){console.error(e);$('resultBox').classList.remove('hidden');$('resultBox').style.borderColor='#e3b2b2';$('resultBox').style.background='#fff4f4';$('resultBox').style.color='#8b2626';$('resultBox').textContent='Generation failed: '+(e.message||e);}
}
function downloadLOD(entries,startsByDocId,p){let csv='SN,Section,Document Title,Project or Checklist Ref,Manufacturer Ref,Revision,Status,Package Start Page,Source Pages,File Name\n';entries.forEach(e=>{const start=e.doc?startsByDocId.get(e.doc.id):null;const vals=[e.sequence,e.section,e.title,e.projectRef,e.manufacturerRef,e.rev,e.status,Number.isInteger(start)?start+1:'',e.doc?.pages||'',e.doc?.name||''].map(v=>'"'+String(v??'').replace(/"/g,'""')+'"');csv+=vals.join(',')+'\n';});downloadBlob(new Blob([csv],{type:'text/csv;charset=utf-8'}),`${(p.documentNo||'submittal').replace(/[^A-Za-z0-9_-]+/g,'_')}_LOD.csv`);}
$('generateBtn').onclick=generatePDF;$('generateBtn2').onclick=generatePDF;

// Restore non-file draft
try{const d=JSON.parse(localStorage.getItem('submittal-studio-draft-v2')||'null');if(d){if(d.project)fieldIds.forEach(id=>{if(d.project[id]!=null)$(id).value=d.project[id]});if(d.defaultSections)state.defaultSections=cloneSectionList(d.defaultSections);if(d.sections)state.sections=cloneSectionList(d.sections);else if(d.defaultSections)state.sections=cloneSectionList(d.defaultSections);if(d.structure)state.structure={...state.structure,...d.structure,items:[]};initSections();const enabled=!!state.structure.enabled;const radio=document.querySelector(`input[name="hasChecklist"][value="${enabled?'yes':'no'}"]`);if(radio)radio.checked=true;$('checklistMode').value=state.structure.mode||'strict';setChecklistEnabled(enabled);}}catch(e){}
renderDocs();updateStructureModeUI();
