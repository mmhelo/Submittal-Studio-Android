#!/usr/bin/env bash
set -euo pipefail
JS=app/src/main/assets/app.js
HTML=app/src/main/assets/index.html
grep -q 'function addSection()' "$JS"
grep -q "state.sections.push" "$JS"
grep -q "addSectionBtn.*onclick=addSection" "$JS"
grep -q 'id="addSectionBtn"' "$HTML"
grep -q 'function nextSectionCode()' "$JS"
echo "Flexible Sections verification: PASS"
