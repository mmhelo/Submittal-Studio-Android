# Submittal Studio Android V2.7

Offline Android build of the Submittal Studio V2.6 flexible-sections workflow.

Key behavior:
- Flexible sections: Add Section / rename / move / delete unused / reset defaults.
- Client Index / Document Register / Checklist workflow with Strict and Assisted modes.
- PDF / ZIP source documents and PDF / DOCX / XLSX checklist parsing.
- Final merged PDF, interactive index, section dividers, bookmarks/navigation and LOD CSV.
- Arabic/Unicode fallback rendering through the device browser canvas.
- No Android INTERNET permission. Project files are processed locally on the device.
- Generated output is saved through Android MediaStore to Downloads/Submittal Studio.

GitHub Actions builds the installable debug APK and publishes it as an Actions artifact.
